<footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
            <div class="col-sm-12">
                    &copy; nfw <?php echo date("Y")?> | Aplikasi Agenda Surat</p>

            </div>
            </div>
        </div>
</footer><!--/#footer-->
